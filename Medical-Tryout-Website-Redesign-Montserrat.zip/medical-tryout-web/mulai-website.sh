#!/bin/sh
cd "$(dirname "$0")" || exit 1
[ -f .env ] || cp .env.example .env
python3 -m uvicorn app.main:app --host 127.0.0.1 --port 8000
