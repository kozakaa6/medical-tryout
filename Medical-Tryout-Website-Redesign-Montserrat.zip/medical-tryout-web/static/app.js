(() => {
  "use strict";
  const app = document.getElementById("app");
  const splash = document.getElementById("splash");
  const toast = document.getElementById("toast");
  const UPLOAD_TYPES = [".pdf", ".docx", ".txt"];
  let maxMB = 10;
  let timerId = null;
  let current = null;
  let serverOffset = 0;
  let saveQueue = Promise.resolve();
  let refreshOnExpire = false;
  let busy = false;
  let toastTimer = null;

  const arrow = '<svg aria-hidden="true" width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round"><path d="M4 12h16m-7-7 7 7-7 7"/></svg>';
  const uploadIcon = '<svg aria-hidden="true" width="23" height="23" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 16V3m-5 5 5-5 5 5"/><path d="M4 16v4h16v-4"/></svg>';
  const clockIcon = '<svg aria-hidden="true" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>';
  const esc = (x) => String(x ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
  function initReveal() {
    const targets = document.querySelectorAll(".reveal-on-scroll");
    if (!targets.length) return;
    if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
      targets.forEach(el => el.classList.add("is-visible"));
      return;
    }
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    }, {threshold: .09, rootMargin: "0px 0px 35px 0px"});
    targets.forEach(el => observer.observe(el));
  }
  const humanSize = n => n >= 1048576 ? (n / 1048576).toFixed(2) + " MB" : Math.max(1, Math.round(n / 1024)) + " KB";
  const formatTime = s => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(Math.floor(s % 60)).padStart(2, "0")}`;
  const brand = (light=false) => `<a href="/" data-link class="brand ${light ? "brand-light" : ""}" aria-label="Medical Tryout - Beranda"><span class="brand-emblem">✚</span><span class="brand-text">Medical Tryout<small>by dr. Eric Septian Perwira</small></span></a>`;
  const header = (light=false, trailing="") => `<header class="header shell">${brand(light)}${trailing || '<span class="header-meta">BELAJAR MEDIS BERBASIS AI</span>'}</header>`;
  const flash = message => {
    clearTimeout(toastTimer); toast.textContent = message; toast.classList.add("show");
    toastTimer = setTimeout(() => toast.classList.remove("show"), 5000);
  };
  async function api(url, opts={}) {
    const res = await fetch(url, {credentials: "same-origin", cache: "no-store", ...opts});
    let json;
    try { json = await res.json(); } catch { json = {}; }
    if (!res.ok) throw new Error(json.detail || "Tidak dapat terhubung ke server.");
    return json;
  }
  const jsonOpts = (method, body) => ({
    method, headers: {"Content-Type": "application/json"}, body: JSON.stringify(body)
  });
  function clearExamTimer() { if (timerId) clearInterval(timerId); timerId = null; current = null; }
  async function go(path, replace=false) {
    clearExamTimer();
    if (location.pathname !== path) history[replace ? "replaceState" : "pushState"]({}, "", path);
    window.scrollTo({top:0, behavior: "auto"});
    await route();
  }
  function renderLanding() {
    app.innerHTML = `
      <div class="landing page-enter">
        <div class="hero-grid" aria-hidden="true"></div>
        ${header(true, '<div class="header-actions"><span class="header-meta"><span class="live-dot"></span> LATIHAN MEDIS BERBASIS AI</span><a class="header-cta" href="/participant" data-link>Mulai Sekarang <span aria-hidden="true">↗</span></a></div>')}
        <main class="shell hero">
          <div class="hero-copy">
            <p class="eyebrow hero-eyebrow"><span class="eyebrow-star" aria-hidden="true">✳</span> BELAJAR MEDIS, LEBIH PERSONAL</p>
            <h1 class="hero-title"><span>Medical</span><span>Tryout<span class="hero-period">.</span></span></h1>
            <p class="hero-by">by <strong>dr. Eric Septian Perwira</strong></p>
            <p class="hero-description">Platform latihan soal medis berbasis AI. Ubah materi belajarmu menjadi tryout interaktif.</p>
            <div class="hero-actions">
              <a class="btn btn-light btn-hero" href="/participant" data-link>
                <span>MULAI TRYOUT</span><span class="btn-circle">${arrow}</span>
              </a>
              <a class="hero-text-link" href="#cara-kerja">Cara kerjanya <span aria-hidden="true">↗</span></a>
            </div>
            <div class="hero-formats">
              <span class="format-status"><span class="format-dot"></span> LATIHAN PERSONAL</span>
              <span class="format-sep" aria-hidden="true"></span>
              <span>PDF · DOCX · TXT</span>
            </div>
          </div>
          <div class="hero-art" role="img" aria-label="Ilustrasi pratinjau tampilan ujian Medical Tryout">
            <div class="art-ring art-ring-one" aria-hidden="true"></div>
            <div class="art-ring art-ring-two" aria-hidden="true"></div>
            <div class="art-spark spark-one" aria-hidden="true">✳</div>
            <div class="art-spark spark-two" aria-hidden="true">✳</div>
            <div class="floating-badge badge-ai"><span class="mini-icon">✦</span><span>SOAL DIBUAT<br><strong>BERBASIS AI</strong></span></div>
            <div class="preview-card">
              <div class="preview-head"><span class="preview-logo">✚</span><span>MEDICAL <b>TRYOUT</b></span><span class="preview-dots"><i></i><i></i><i></i></span></div>
              <div class="preview-inner">
                <span class="preview-eyebrow">SIMULASI TAMPILAN CBT</span>
                <div class="preview-count"><span>01 <small>/ 10</small></span><span class="preview-time">◷ 01:00</span></div>
                <div class="preview-bar"><i></i></div>
                <div class="preview-q">Satu soal.<br><em>Satu fokus.</em></div>
                <div class="preview-choice"><span>A</span><span class="preview-line long"></span><i></i></div>
                <div class="preview-choice chosen"><span>B</span><span class="preview-line medium"></span><span class="choice-check">✓</span></div>
                <div class="preview-choice"><span>C</span><span class="preview-line short"></span><i></i></div>
                <div class="preview-next">SOAL BERIKUTNYA <span aria-hidden="true">→</span></div>
              </div>
            </div>
            <div class="floating-badge badge-focus"><span class="focus-icon">◎</span><span>SATU FOKUS<br><strong>60 DETIK / SOAL</strong></span></div>
            <span class="art-label">CARA BARU BELAJAR MEDIS — 2026</span>
          </div>
        </main>
        <section class="hero-bottom shell" aria-label="Keunggulan platform">
          <div class="hero-feature"><span class="n">01</span><strong>Materimu sendiri</strong><span class="feature-arc" aria-hidden="true">↗</span></div>
          <div class="hero-feature"><span class="n">02</span><strong>Soal berbasis AI</strong><span class="feature-arc" aria-hidden="true">↗</span></div>
          <div class="hero-feature"><span class="n">03</span><strong>Evaluasi mendalam</strong><span class="feature-arc" aria-hidden="true">↗</span></div>
        </section>
      </div>
      <section class="steps-section" id="cara-kerja" aria-labelledby="steps-title">
        <div class="shell">
          <div class="steps-top reveal-on-scroll">
            <div><p class="eyebrow section-eyebrow">BUKAN SEKADAR LATIHAN</p><h2 id="steps-title">Belajar lebih cerdas.<br><span>Mulai dari materimu.</span></h2></div>
            <p>Dari materi yang kamu pelajari, menjadi pengalaman tryout yang lebih terarah, praktis, dan personal.</p>
          </div>
          <div class="steps-grid">
            <article class="step-card reveal-on-scroll"><div class="step-card-head"><span class="step-index">01 / UNGGAH</span><span class="step-symbol" aria-hidden="true">↥</span></div><h3>Unggah materi</h3><p>Pilih PDF, DOCX, atau TXT yang ingin kamu pelajari.</p><div class="step-decoration"><span>PDF</span><span>DOCX</span><span>TXT</span></div></article>
            <article class="step-card reveal-on-scroll"><div class="step-card-head"><span class="step-index">02 / BUAT SOAL</span><span class="step-symbol" aria-hidden="true">✳</span></div><h3>AI susun soal</h3><p>Pertanyaan dibuat berdasarkan materi yang kamu unggah.</p><div class="step-decoration pulse-line" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div></article>
            <article class="step-card reveal-on-scroll"><div class="step-card-head"><span class="step-index">03 / EVALUASI</span><span class="step-symbol" aria-hidden="true">◎</span></div><h3>Uji kemampuan</h3><p>Kerjakan soal CBT, lalu lihat nilai dan pembahasannya.</p><div class="step-decoration chart-bars" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div></article>
          </div>
          <div class="steps-end reveal-on-scroll"><span>SIAP SAAT KAMU SIAP.</span><a class="steps-start" href="/participant" data-link>Mulai latihan sekarang <span aria-hidden="true">↗</span></a></div>
        </div>
      </section>
      <footer class="landing-footer"><div class="shell"><span>© MEDICAL TRYOUT · DR. ERIC SEPTIAN PERWIRA</span><span>DIBUAT UNTUK BELAJAR LEBIH BAIK</span></div></footer>`;
    initReveal();
  }

  function renderParticipant() {
    app.innerHTML = `
      <div class="light-page page-enter">
        ${header(false, '<span class="step-pill"><span class="dot"></span> SIAP BERLATIH</span>')}
        <main class="shell form-main">
          <div class="form-intro">
            <p class="eyebrow">PLATFORM UJIAN MEDIS PERSONAL</p>
            <h1 class="display-heading">Materi<br>doktermu.<br><span>Tryout yang<br>lebih terarah.</span></h1>
            <p class="lead">Unggah materi pilihanmu dan biarkan AI menyusunnya menjadi soal latihan yang relevan. Satu sesi, satu fokus, kemajuan yang nyata.</p>
            <div class="form-metrics" aria-label="Format tryout">
              <div class="metric"><b>10</b><small>Maksimal soal</small></div>
              <div class="metric"><b>60<span style="font-size:.55em">s</span></b><small>Per pertanyaan</small></div>
              <div class="metric"><b>A–D</b><small>Pilihan jawaban</small></div>
            </div>
          </div>
          <section class="form-panel" aria-label="Formulir peserta dan materi">
            <div class="panel-header">
              <div><h2 class="panel-title">Mulai dari materi</h2><p class="panel-subtitle">Isi data singkat dan unggah dokumen Anda.</p></div>
              <span class="form-step">01 / 02</span>
            </div>
            <form id="participant-form" novalidate>
              <div class="field">
                <label class="label" for="name">Nama Lengkap</label>
                <input class="control" type="text" id="name" name="name" placeholder="Masukkan nama lengkap Anda" maxlength="120" autocomplete="name" required>
              </div>
              <div class="field-row">
                <div class="field"><label class="label" for="age">Umur</label><input class="control" id="age" name="age" type="number" min="1" max="120" step="1" placeholder="Contoh: 24" required inputmode="numeric"></div>
                <div class="field"><label class="label" for="job">Pekerjaan <span class="optional">(Opsional)</span></label><input class="control" id="job" name="job" maxlength="120" type="text" placeholder="Contoh: Mahasiswa Kedokteran, Dokter, Koas"></div>
              </div>
              <div class="upload-head"><label class="label" for="upload-input" style="margin:0">Upload Materi Tryout</label><span class="file-note">PDF, DOCX, TXT · Maks. ${maxMB} MB</span></div>
              <div class="dropzone" id="dropzone" role="button" tabindex="0" aria-label="Pilih atau seret berkas materi">
                <div class="drop-icon">${uploadIcon}</div>
                <strong>Upload materi yang ingin dijadikan soal</strong>
                <p>Seret dokumen ke sini atau <span class="upload-choose">pilih berkas</span></p>
                <p>Dokumen diproses secara aman di server.</p>
              </div>
              <input type="file" id="upload-input" name="file" accept=".pdf,.docx,.txt,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain" class="sr-only">
              <div id="file-details" aria-live="polite"></div>
              <p id="form-error" class="form-errors" role="alert" aria-live="assertive"></p>
              <div id="process" aria-live="polite"></div>
              <button class="btn btn-primary btn-block" id="generate-button" type="submit" disabled>GENERATE SOAL &amp; MULAI TRYOUT ${arrow}</button>
              <p class="form-footnote">Hanya materi yang dapat dibaca akan dijadikan soal. Kunci jawaban tersimpan di server.</p>
            </form>
          </section>
        </main>
      </div>`;
    bindParticipant();
  }

  function bindParticipant() {
    const form = document.getElementById("participant-form");
    const name = document.getElementById("name");
    const age = document.getElementById("age");
    const job = document.getElementById("job");
    const input = document.getElementById("upload-input");
    const drop = document.getElementById("dropzone");
    const details = document.getElementById("file-details");
    const error = document.getElementById("form-error");
    const process = document.getElementById("process");
    const submit = document.getElementById("generate-button");
    let file = null, sending = false;

    function fileError(f) {
      if (!f) return "Pilih dokumen materi terlebih dahulu.";
      if (!UPLOAD_TYPES.some(ext => f.name.toLowerCase().endsWith(ext))) return "Gunakan berkas PDF, DOCX, atau TXT.";
      if (!f.size) return "Berkas kosong tidak dapat diunggah.";
      if (f.size > maxMB * 1048576) return `Ukuran berkas melebihi ${maxMB} MB.`;
      return "";
    }
    function update() {
      const validName = name.value.trim().length >= 2 && name.value.trim().length <= 120;
      const validAge = /^\d+$/.test(age.value.trim()) && Number(age.value) >= 1 && Number(age.value) <= 120;
      submit.disabled = sending || !(validName && validAge && !fileError(file));
    }
    function showFile() {
      error.textContent = file ? fileError(file) : "";
      details.innerHTML = file ? `<div class="file-row"><div><div class="file-name">✓ ${esc(file.name)}</div><div class="file-detail">${esc(humanSize(file.size))} · ${fileError(file) ? "Berkas tidak valid" : "Siap diproses"}</div></div><div class="file-actions"><button type="button" class="tiny-action" id="replace-file">Ganti</button><button type="button" class="tiny-action" id="remove-file">Hapus</button></div></div>` : "";
      document.getElementById("replace-file")?.addEventListener("click", () => input.click());
      document.getElementById("remove-file")?.addEventListener("click", () => {file=null;input.value="";showFile();});
      update();
    }
    function setFile(candidate) {file = candidate || null;showFile();}
    [name, age, job].forEach(el => el.addEventListener("input", () => {error.textContent="";update();}));
    input.addEventListener("change", () => {if (input.files?.[0]) setFile(input.files[0]);});
    drop.addEventListener("click", () => {if (!sending) input.click();});
    drop.addEventListener("keydown", e => {if (e.key === "Enter" || e.key === " ") {e.preventDefault();if (!sending) input.click();}});
    ["dragenter","dragover"].forEach(event => drop.addEventListener(event, e => {e.preventDefault();drop.classList.add("dragover");}));
    ["dragleave","drop"].forEach(event => drop.addEventListener(event, e => {e.preventDefault();drop.classList.remove("dragover");}));
    drop.addEventListener("drop", e => {if (!sending && e.dataTransfer?.files?.length) setFile(e.dataTransfer.files[0]);});
    form.addEventListener("submit", async e => {
      e.preventDefault();
      if (sending) return;
      const issue = fileError(file);
      if (name.value.trim().length < 2) {error.textContent = "Nama lengkap harus berisi minimal dua karakter.";name.focus();return;}
      if (!/^\d+$/.test(age.value.trim()) || Number(age.value) < 1 || Number(age.value) > 120) {error.textContent = "Umur harus bilangan bulat antara 1–120.";age.focus();return;}
      if (issue) {error.textContent = issue;drop.focus();return;}
      sending=true;update();error.textContent="";
      process.innerHTML = '<div class="progress-process"><span class="spinner"></span><span id="phase-message">Mengirim dokumen...</span></div>';
      const payload = new FormData();
      payload.append("name",name.value.trim());
      payload.append("age",age.value.trim());
      payload.append("job",job.value.trim());
      payload.append("file",file,file.name);
      try {
        const response = await fetch("/api/generate",{method:"POST",credentials:"same-origin",body:payload,cache:"no-store"});
        if (!response.ok) {
          const body = await response.json().catch(() => ({}));
          throw new Error(body.detail || "Gagal memproses dokumen.");
        }
        if (!response.body) throw new Error("Browser tidak mendukung pembacaan respons ini.");
        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let carry = "", ready=false;
        while (true) {
          const {value,done} = await reader.read();
          carry += decoder.decode(value || new Uint8Array(),{stream:!done});
          const lines=carry.split("\n");
          carry=lines.pop() || "";
          for (const line of lines) {
            if (!line.trim()) continue;
            const event=JSON.parse(line);
            if (event.type === "phase") document.getElementById("phase-message").textContent=event.message;
            else if (event.type === "error") throw new Error(event.message);
            else if (event.type === "ready") ready=true;
          }
          if (done) break;
        }
        if (!ready) throw new Error("Proses belum selesai. Coba lagi.");
        await go("/exam");
      } catch (ex) {
        error.textContent = ex.message || "Terjadi gangguan saat memproses materi.";
        process.innerHTML = "";
        error.scrollIntoView({block:"nearest"});
      } finally {
        sending=false;update();
      }
    });
    update();
  }

  function applyExam(data) {
    clearExamTimer();
    if (data.stage === "results") {go("/results",true);return;}
    current = {...data};
    refreshOnExpire=false;
    saveQueue=Promise.resolve();
    serverOffset = data.server_now * 1000 - Date.now();
    const letters = ["A","B","C","D"];
    const pct = Math.round(((data.index + 1) / data.total) * 100);
    const nameInitial = [...data.name.trim()][0]?.toUpperCase() || "P";
    app.innerHTML = `
      <div class="exam-page page-enter">
        <div class="exam-header"><header class="header shell">${brand()}<div class="exam-user"><div class="user-circle" aria-hidden="true">${esc(nameInitial)}</div><div><strong>${esc(data.name)}</strong><span>Peserta tryout</span></div></div></header></div>
        <main class="exam-container">
          <div class="exam-topline">
            <div><p class="eyebrow">UJIAN BERBASIS KOMPUTER · MEDICAL TRYOUT</p><h1>Soal ${data.index+1} <span style="color:#99ADC3">/ ${data.total}</span></h1></div>
            <div class="exam-timebox" id="timebox" aria-label="Waktu tersisa">
              ${clockIcon}<div><span class="time-caption">Sisa waktu</span><div class="time-num" id="timer" role="timer" aria-live="off">01:00</div></div>
            </div>
          </div>
          <div class="progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="${data.total}" aria-valuenow="${data.index+1}" aria-label="Kemajuan ujian"><div class="progress-fill" style="width:${pct}%"></div></div>
          <section class="question-card" aria-labelledby="question-title">
            <div class="question-tag"><span>PERTANYAAN ${String(data.index+1).padStart(2,"0")}</span><span>Pilih satu jawaban paling tepat</span></div>
            <h2 id="question-title" class="question-text">${esc(data.question.text)}</h2>
            <div class="answers" role="radiogroup" aria-label="Pilihan jawaban">
              ${letters.map(letter => `<button type="button" class="answer ${data.selected === letter ? "selected" : ""}" role="radio" aria-checked="${data.selected===letter}" data-choice="${letter}" ${data.locked ? "disabled":""}><span class="letter">${letter}</span><span class="body">${esc(data.question.choices[letter])}</span><span class="check" aria-hidden="true">${data.selected===letter ? "✓" : ""}</span></button>`).join("")}
            </div>
            <div id="exam-notice" aria-live="polite">${data.locked ? '<div class="exam-notice">Waktu untuk soal ini telah habis.</div>' : ""}</div>
          </section>
          <div class="exam-controls"><p class="exam-hint" id="exam-hint">Jawaban tersimpan secara otomatis. Tekan tombol berikut untuk melanjutkan. Soal yang telah dilewati tidak dapat diedit kembali.</p><button type="button" class="btn btn-primary" id="advance-button">${data.index === data.total-1 ? "SELESAIKAN TRYOUT" : "LANJUT"} ${arrow}</button></div>
          <p class="security-line">Jawaban benar akan ditampilkan setelah seluruh tryout diselesaikan.</p>
        </main>
      </div>`;
    document.querySelectorAll("[data-choice]").forEach(el => el.addEventListener("click", () => select(el.dataset.choice)));
    document.getElementById("advance-button").addEventListener("click", advanceExam);
    tick();
    timerId=setInterval(tick,250);
  }
  function paintSelection() {
    document.querySelectorAll("[data-choice]").forEach(el => {
      const selected=el.dataset.choice === current.selected;
      el.classList.toggle("selected",selected);
      el.setAttribute("aria-checked",String(selected));
      el.disabled=!!current.locked;
      el.querySelector(".check").textContent=selected ? "✓" : "";
    });
  }
  function lockView() {
    if (!current) return;
    current.locked=true;
    paintSelection();
    document.getElementById("exam-notice").innerHTML='<div class="exam-notice">Waktu untuk soal ini telah habis.</div>';
    const box=document.getElementById("timebox");
    if (box) box.classList.add("warning");
  }
  function tick() {
    if (!current) return;
    const remaining = Math.max(0,Math.ceil((current.deadline * 1000 - (Date.now()+serverOffset)) / 1000));
    const el=document.getElementById("timer");
    if (!el) return;
    el.textContent=formatTime(remaining);
    const box=document.getElementById("timebox");
    box?.classList.toggle("warning",remaining <= 15);
    if (remaining === 0 && !current.locked) {
      lockView();
      if (!refreshOnExpire) {
        refreshOnExpire=true;
        saveQueue.finally(async () => {
          try {
            const latest=await api("/api/session");
            if (current && latest.stage==="exam" && latest.index===current.index) {
              current.selected=latest.selected; current.locked=latest.locked;paintSelection();
            }
          } catch { /* Server still enforces expiry on next mutation. */ }
        });
      }
    }
  }
  function select(choice) {
    if (!current || current.locked || busy) return;
    const idx=current.index;
    current.selected=choice;
    paintSelection();
    saveQueue=saveQueue.catch(() => {}).then(async () => {
      try {
        const result=await api("/api/answer",jsonOpts("PUT",{index:idx,selected:choice}));
        if (!current || current.index!==idx) return;
        current.selected=result.selected;
        if (result.locked) lockView();
        paintSelection();
      } catch(e) {
        flash("Jawaban belum tersimpan: "+e.message);
        try {
          const actual=await api("/api/session");
          if(current && actual.index===idx){current.selected=actual.selected;current.locked=actual.locked;paintSelection();}
        } catch {}
      }
    });
  }
  async function advanceExam() {
    if (!current || busy) return;
    busy=true;
    const btn=document.getElementById("advance-button");
    btn.disabled=true;
    btn.textContent="MEMPROSES...";
    try {
      await saveQueue.catch(()=>{});
      const result=await api("/api/advance",jsonOpts("POST",{index:current.index}));
      if (result.stage === "results") await go("/results");
      else applyExam(result);
    } catch(e) {
      flash(e.message);
      btn.disabled=false;
      btn.innerHTML=(current.index===current.total-1 ? "SELESAIKAN TRYOUT" : "LANJUT")+" "+arrow;
    } finally {
      busy=false;
    }
  }
  function renderResults(data) {
    const statusLabel={correct:"Benar",incorrect:"Salah",unanswered:"Tidak dijawab"};
    const scoreText=Number(data.score)%1===0?String(data.score):Number(data.score).toFixed(1);
    app.innerHTML=`
      <div class="results-page page-enter">
        ${header(false,'<span class="step-pill"><span class="dot"></span> SELESAI</span>')}
        <main class="results-wrap">
          <section class="result-banner">
            <div><p class="eyebrow">RANGKUMAN PERFORMA</p><h1>HASIL MEDICAL TRYOUT</h1><p>Tryout selesai, ${esc(data.name)}. Pelajari kembali jawaban dan pembahasan untuk menguatkan pemahamanmu.</p></div>
            <div class="score-disc" style="--score:${Math.max(0,Math.min(100, Number(data.score)))}" aria-label="Skor ${scoreText} dari 100"><b>${scoreText}</b><small>SKOR / 100</small></div>
          </section>
          <section class="result-stats" aria-label="Statistik hasil">
            <div class="result-stat"><b>${data.total}</b><small>Total soal</small></div>
            <div class="result-stat"><b>${data.correct}</b><small>Jawaban benar</small></div>
            <div class="result-stat"><b>${data.incorrect}</b><small>Jawaban salah</small></div>
            <div class="result-stat"><b>${data.unanswered}</b><small>Tidak dijawab</small></div>
          </section>
          <div class="review-head"><div><p class="eyebrow">ULASAN DAN PEMBELAJARAN</p><h2>Pembahasan setiap soal</h2><p style="font-size:11px;color:#8398AE;margin:6px 0 0">Waktu aktif: ${formatTime(Math.round(data.active_seconds))}</p></div><button type="button" id="retry-button" class="btn btn-primary">COBA LAGI ${arrow}</button></div>
          <div class="review-list">
            ${data.reviews.map((q,i)=>`
              <details class="review-item" ${i===0?"open":""}>
                <summary class="review-summary">
                  <span class="review-index">${String(i+1).padStart(2,"0")}</span>
                  <span class="review-title">${esc(q.text)}</span>
                  <span class="review-badge ${q.status}">${statusLabel[q.status]}</span>
                  <span class="review-chevron" aria-hidden="true">⌄</span>
                </summary>
                <div class="review-detail">
                  <div class="review-options">${["A","B","C","D"].map(c=>`<div class="review-option ${c===q.correct?"right":c===q.selected?"wrong":""}"><b>${c}.</b> ${esc(q.choices[c])}${c===q.correct?" · Kunci jawaban":""}${c===q.selected && c!==q.correct?" · Jawaban Anda":""}</div>`).join("")}</div>
                  <p class="review-answer"><strong>Jawaban Anda:</strong> ${q.selected ? esc(q.selected+" — "+q.choices[q.selected]) : "Tidak dijawab"}</p>
                  <p class="review-answer"><strong>Jawaban benar:</strong> ${esc(q.correct+" — "+q.choices[q.correct])}</p>
                  <div class="review-explanation"><strong>Pembahasan</strong><div>${esc(q.explanation)}</div></div>
                  ${q.source_ref?`<p class="review-ref">Sumber materi: ${esc(q.source_ref)}</p>`:""}
                </div>
              </details>`).join("")}
          </div>
          <p class="footer-note">Medical Tryout · by dr. Eric Septian Perwira</p>
        </main>
      </div>`;
    document.getElementById("retry-button").addEventListener("click",async()=>{
      try {await api("/api/reset",{method:"POST"}); await go("/");}
      catch(e){flash(e.message);}
    });
  }
  async function route() {
    const path = location.pathname;
    if (path === "/participant") {renderParticipant();return;}
    if (path === "/exam") {
      try {
        const session=await api("/api/session");
        if (session.stage === "results") await go("/results",true);
        else applyExam(session);
      } catch(e) {
        flash(e.message);
        await go("/participant",true);
      }
      return;
    }
    if (path === "/results") {
      try {renderResults(await api("/api/results"));}
      catch(e) {flash(e.message);await go("/exam",true);}
      return;
    }
    renderLanding();
  }

  document.addEventListener("pointerdown", e => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const target = e.target.closest(".btn, .header-cta");
    if (!target || target.disabled) return;
    const rect = target.getBoundingClientRect();
    const ripple = document.createElement("span");
    ripple.className = "tap-ripple";
    ripple.setAttribute("aria-hidden", "true");
    ripple.style.left = `${e.clientX - rect.left}px`;
    ripple.style.top = `${e.clientY - rect.top}px`;
    target.appendChild(ripple);
    ripple.addEventListener("animationend", () => ripple.remove(), {once:true});
  });

  document.addEventListener("click",e=>{
    const link=e.target.closest("a[data-link]");
    if (!link || e.ctrlKey || e.metaKey || e.shiftKey || e.altKey || e.button!==0) return;
    e.preventDefault();
    go(new URL(link.href).pathname);
  });
  window.addEventListener("popstate",()=>{clearExamTimer();route();});
  document.addEventListener("visibilitychange",()=>{if (!document.hidden) tick();});

  (async () => {
    try {
      const cfg=await api("/api/config");
      if (cfg.max_upload_mb) maxMB=cfg.max_upload_mb;
    } catch { /* Server-side validation remains authoritative. */ }
    await route();
    let visited=false;
    try {visited=sessionStorage.getItem("mt_splash_seen")==="yes";sessionStorage.setItem("mt_splash_seen","yes");} catch {}
    const reduce=window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    setTimeout(() => splash.classList.add("hide"), visited || reduce ? 80 : 2850);
  })();
})();
