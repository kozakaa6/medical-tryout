# Medical Tryout — Website Ujian Medis Berbasis AI

Website responsif untuk **Medical Tryout by dr. Eric Septian Perwira**. Dapat dibuka lewat browser desktop maupun smartphone. Ini **website**, bukan aplikasi Android/iOS yang perlu diinstal.

> **Status:** UI dan alur backend telah dibuat serta diuji secara lokal. Integrasi AI memakai request API nyata, tetapi panggilan ke penyedia AI belum dapat diverifikasi tanpa kunci API. Website tidak membuat soal palsu ketika API belum dikonfigurasi.

## Cara menjalankan

Persyaratan: Python 3.11+ dan koneksi internet ketika pertama kali menginstal dependensi.

1. Ekstrak ZIP proyek, lalu buka terminal di folder `medical-tryout-web`.
2. Buat virtual environment dan instal dependensi:

   **Windows (PowerShell):**
   ```powershell
   py -m venv .venv
   .venv\Scripts\Activate.ps1
   python -m pip install -r requirements.txt
   Copy-Item .env.example .env
   ```

   **macOS / Linux:**
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   python -m pip install -r requirements.txt
   cp .env.example .env
   ```

3. Buka `.env` dan isi `AI_API_KEY` dengan kunci API penyedia yang kompatibel dengan OpenAI Chat Completions. Sesuaikan `AI_MODEL` dan `AI_BASE_URL` bila perlu.
4. Jalankan server:
   ```bash
   python -m uvicorn app.main:app --reload --port 8000
   ```
5. Kunjungi **http://127.0.0.1:8000** di browser.

Jika hanya ingin melihat tampilan, website tetap bisa dibuka tanpa API key. Fitur menghasilkan soal akan menampilkan pesan konfigurasi yang sesuai sampai API key diisi.

### Menjalankan pengujian

```bash
python -m pytest -q
node --check static/app.js
```

Node digunakan **hanya untuk memeriksa sintaks JavaScript**, bukan untuk menjalankan website.

## Pembaruan desain interaktif (Montserrat)

Versi ini mempertahankan warna navy (`#0A2344`), navy gelap (`#071629`), dan putih, serta menggunakan **Montserrat** melalui Google Fonts.

- Hero landing baru: tipografi lebih berani, tombol **MULAI TRYOUT** berbentuk kapsul (bukan kotak), dengan panah yang bergerak saat hover.
- Pratinjau visual CBT, badge melayang, pola grid halus, dan tiga keunggulan utama.
- Bagian **Cara kerjanya** dengan kartu informatif dan animasi muncul saat halaman digulir.
- Animasi tekan berbentuk ripple pada tombol utama, umpan balik hover, dan animasi masuk tiap halaman.
- Form, drag-and-drop, kartu soal, pilihan jawaban, dan halaman hasil memiliki permukaan lebih lembut dan interaksi yang konsisten.
- Animasi hiasan dimatikan bagi pengguna dengan preferensi `prefers-reduced-motion`.
- Ilustrasi ujian pada landing adalah **pratinjau visual**, bukan soal atau hasil AI yang sesungguhnya.

## Halaman dan alur

1. **Animasi awal:** logo resmi di atas latar navy; tidak berulang pada navigasi biasa di tab yang sama.
2. **Landing:** headline Medical Tryout dan tombol **MULAI TRYOUT**.
3. **Peserta & upload:** Nama Lengkap, Umur, Pekerjaan opsional, unggah/drag-drop PDF, DOCX, atau TXT (maksimal 10 MB).
4. **CBT:** satu soal pada satu waktu, empat opsi A–D, batas 60 detik per soal, penyimpanan jawaban sementara di server, tombol **LANJUT** / **SELESAIKAN TRYOUT**.
5. **Hasil:** skor, statistik benar/salah/kosong, waktu aktif, kunci dan pembahasan setelah sesi ditutup.

## Arsitektur & berkas penting

- `static/index.html` — HTML utama, sumber branding dan pemuatan aset.
- `static/styles.css` — gaya navy/putih, layout responsif, transisi serta reduced-motion.
- `static/app.js` — navigasi SPA, form upload, ujian satu soal per layar, timer, hasil.
- `static/assets/medical-tryout-logo.png` — logo asli dari lampiran.
- `static/assets/design-reference.jpeg` — gambar referensi asli.
- `app/main.py` — FastAPI server, endpoint upload/ujian/hasil, cookie sesi.
- `app/documents.py` — ekstraksi PDF berbasis teks, DOCX, dan TXT UTF-8.
- `app/ai.py` — panggilan AI nyata, schema Pydantic, pemeriksaan konten dan percobaan ulang terbatas.
- `app/store.py` — sesi SQLite, deadline otoritatif server, penguncian jawaban, perhitungan nilai.
- `app/config.py` — konfigurasi server dari environment / `.env`.
- `tests/` — unit test dan pengujian API.

Desain frontend menggunakan HTML/CSS/JavaScript tanpa framework agar website dapat dijalankan langsung di lingkungan ini. **Ini bukan proyek Next.js/Tailwind**; keduanya tidak dapat diinstal dari registry npm pada lingkungan pembuatan. FastAPI adalah backend website, bukan aplikasi desktop/native.

## AI dan pengolahan dokumen

- Provider: endpoint yang kompatibel dengan OpenAI `POST /chat/completions`.
- Kredensial hanya berada di server, tidak dikirim ke browser.
- Server mengekstrak teks; PDF hasil scan tanpa teks akan ditolak (belum tersedia OCR).
- Pertanyaan maksimal 10 dengan opsi A–D, kunci, penjelasan dan referensi sumber saat tersedia.
- Output disaring schema dan cek kualitas dasar; ini **tidak menjamin akurasi klinis**. Periksa hasil pembahasan dengan materi sumber.
- Tanpa API key, koneksi gagal, atau materi tak memadai, proses gagal dengan pesan nyata; tidak ada generator soal contoh tersembunyi.

## Keamanan, penyimpanan, dan batas produksi

- Berkas asli diproses di memori/request lalu tidak disimpan sebagai berkas dokumen permanen.
- SQLite hanya menyimpan informasi peserta terbatas, soal dan jawaban (tidak menyimpan dokumen asli).
- Token sesi acak berada di cookie HttpOnly SameSite=Strict; hash token yang disimpan di SQLite.
- Deadline `started_at` dan `deadline_at` dikontrol server, tidak direset saat refresh.
- Jawaban benar dan penjelasan tidak tersedia melalui endpoint ujian aktif.
- Sesi berakhir setelah `SESSION_TTL_HOURS` (default 12 jam). Sesi kedaluwarsa ditolak saat diakses; data dibersihkan saat startup dan ketika membuat sesi baru.
- Saat deploy melalui HTTPS aktifkan `COOKIE_SECURE=true`, gunakan pembatasan request/rate-limit, monitoring, kebijakan privasi dan penghapusan data reguler.
- SQLite cocok untuk satu server / pengembangan lokal; untuk sistem multi-instance/serverless sebaiknya pindahkan sesi ke database bersama yang transaksional seperti PostgreSQL.
- Website belum dideploy ke domain publik dan permintaan AI live belum diuji karena kunci API tidak tersedia.

## Mengubah branding

Edit warna di `static/styles.css` (`:root`). Logo asli sudah tersedia dan ditampilkan pada animasi awal. Foto laptop hanya dipakai sebagai referensi estetika, bukan sebagai latar website.
