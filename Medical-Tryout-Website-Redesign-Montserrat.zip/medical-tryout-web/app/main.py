"""Medical Tryout API and responsive web app."""
from __future__ import annotations
import json
import secrets
from contextlib import asynccontextmanager
from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, ValidationError
from . import config, store, documents, ai

ROOT = Path(__file__).resolve().parent.parent
COOKIE = "medical_tryout_session"

@asynccontextmanager
async def lifespan(app: FastAPI):
    store.initialize()
    yield

app = FastAPI(title="Medical Tryout", docs_url=None, redoc_url=None, lifespan=lifespan)
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

@app.middleware("http")
async def security_headers(request: Request, call_next):
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        origin = request.headers.get("origin")
        if origin:
            from urllib.parse import urlsplit
            target = urlsplit(origin)
            if target.netloc != request.url.netloc or target.scheme not in ("http", "https"):
                return JSONResponse({"detail": "Permintaan lintas situs ditolak."}, status_code=403)
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["Referrer-Policy"] = "no-referrer"
    if request.url.path.startswith("/api/"):
        response.headers["Cache-Control"] = "no-store"
    return response

@app.get("/")
@app.get("/participant")
@app.get("/exam")
@app.get("/results")
async def index():
    return FileResponse(ROOT / "static/index.html")

@app.get("/api/config")
def public_config():
    return {"max_upload_mb": config.MAX_UPLOAD_BYTES // (1024 * 1024)}

def _error(exc: Exception):
    if isinstance(exc, store.SessionError):
        return JSONResponse({"detail": str(exc)}, status_code=exc.status)
    return JSONResponse({"detail": "Terjadi kesalahan server. Coba lagi."}, status_code=500)

def _cookie(request: Request):
    return request.cookies.get(COOKIE, "")

@app.post("/api/generate")
async def generate(request: Request):
    # Client-side validation is only for UX; validate independently on server.
    try:
        form = await request.form(max_files=1, max_fields=5)
        name = str(form.get("name", "")).strip()
        age_str = str(form.get("age", "")).strip()
        job = str(form.get("job", "")).strip()
        uploaded = form.get("file")
        if not 2 <= len(name) <= 120:
            return JSONResponse({"detail": "Nama lengkap harus berisi 2–120 karakter."}, status_code=422)
        if not age_str.isdecimal() or not 1 <= int(age_str) <= 120:
            return JSONResponse({"detail": "Umur harus berupa bilangan bulat antara 1–120."}, status_code=422)
        if len(job) > 120:
            return JSONResponse({"detail": "Pekerjaan maksimal 120 karakter."}, status_code=422)
        if not uploaded or not hasattr(uploaded, "read"):
            return JSONResponse({"detail": "Pilih dokumen PDF, DOCX, atau TXT terlebih dahulu."}, status_code=422)
        filename = getattr(uploaded, "filename", "") or ""
        if not filename.lower().endswith((".pdf", ".docx", ".txt")):
            return JSONResponse({"detail": "Format berkas tidak didukung. Gunakan PDF, DOCX, atau TXT."}, status_code=422)
        data = await uploaded.read(config.MAX_UPLOAD_BYTES + 1)
        await uploaded.close()
        if len(data) > config.MAX_UPLOAD_BYTES:
            return JSONResponse({"detail": f"Berkas terlalu besar. Maksimum {config.MAX_UPLOAD_BYTES // 1048576} MB."}, status_code=413)
        if not data:
            return JSONResponse({"detail": "Berkas kosong. Silakan pilih yang lain."}, status_code=422)
    except Exception:
        return JSONResponse({"detail": "Formulir tidak dapat dibaca. Coba unggah ulang."}, status_code=400)

    token = secrets.token_urlsafe(32)

    async def stream():
        def line(kind: str, message: str):
            return json.dumps({"type": kind, "message": message}, ensure_ascii=False) + "\n"
        try:
            yield line("phase", "Membaca materi...")
            doc = documents.extract_document(filename, data)
            yield line("phase", "Menyusun soal...")
            questions = await ai.generate_questions(doc)
            yield line("phase", "Menyiapkan tryout...")
            store.create_session(name, int(age_str), job, questions, token=token)
            yield line("ready", "Tryout siap dimulai.")
        except (documents.DocumentError, ai.GenerationError, store.SessionError) as exc:
            yield line("error", str(exc))
        except Exception:
            yield line("error", "Terjadi gangguan saat memproses materi. Coba lagi.")

    response = StreamingResponse(stream(), media_type="application/x-ndjson; charset=utf-8")
    response.set_cookie(COOKIE, token, max_age=config.SESSION_TTL_HOURS * 3600,
                        httponly=True, secure=config.COOKIE_SECURE, samesite="strict", path="/")
    return response

class Selection(BaseModel):
    index: int
    selected: str | None

class Advancement(BaseModel):
    index: int

@app.get("/api/session")
def current(request: Request):
    try:
        return store.get_current(_cookie(request))
    except Exception as exc:
        return _error(exc)

@app.put("/api/answer")
def select_answer(body: Selection, request: Request):
    if body.selected is not None and body.selected not in ("A", "B", "C", "D"):
        return JSONResponse({"detail": "Pilihan jawaban tidak valid."}, status_code=422)
    try:
        return store.save_answer(_cookie(request), body.index, body.selected)
    except Exception as exc:
        return _error(exc)

@app.post("/api/advance")
def next_question(body: Advancement, request: Request):
    try:
        return store.advance(_cookie(request), body.index)
    except Exception as exc:
        return _error(exc)

@app.get("/api/results")
def results(request: Request):
    try:
        return store.get_results(_cookie(request))
    except Exception as exc:
        return _error(exc)

@app.post("/api/reset")
def reset():
    response = JSONResponse({"stage": "landing"})
    response.delete_cookie(COOKIE, path="/")
    return response
