"""Durable SQLite exam state. Secrets and answer keys never appear in active exam payloads."""
from __future__ import annotations
from contextlib import contextmanager
import hashlib
import json
import os
import secrets
import sqlite3
import time
from . import config

class SessionError(RuntimeError):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.status = status

def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()

@contextmanager
def _db(write: bool = False):
    path = config.DATABASE_PATH
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    conn = sqlite3.connect(path, timeout=15, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    conn.execute("PRAGMA busy_timeout = 15000")
    try:
        if write:
            conn.execute("BEGIN IMMEDIATE")
        yield conn
        if write:
            conn.commit()
    except BaseException:
        if write:
            conn.rollback()
        raise
    finally:
        conn.close()

def initialize():
    with _db(write=True) as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS sessions (
                id TEXT PRIMARY KEY, name TEXT NOT NULL, age INTEGER NOT NULL,
                job TEXT NOT NULL DEFAULT '', questions_json TEXT NOT NULL,
                total INTEGER NOT NULL, current_idx INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL, expires_at REAL NOT NULL,
                completed_at REAL
            );
            CREATE TABLE IF NOT EXISTS answers (
                session_id TEXT NOT NULL, idx INTEGER NOT NULL,
                selected TEXT, started_at REAL NOT NULL,
                deadline_at REAL NOT NULL, finalized_at REAL,
                PRIMARY KEY(session_id, idx),
                FOREIGN KEY(session_id) REFERENCES sessions(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_session_expires ON sessions(expires_at);
        """)
    cleanup()

def cleanup():
    with _db(write=True) as db:
        db.execute("DELETE FROM sessions WHERE expires_at < ?", (time.time(),))

def create_session(name: str, age: int, job: str, questions: list[dict], token: str | None = None) -> str:
    if not questions:
        raise SessionError("Tidak ada soal yang dapat dijalankan.")
    token = token or secrets.token_urlsafe(32)
    now = time.time()
    with _db(write=True) as db:
        db.execute("DELETE FROM sessions WHERE expires_at < ?", (now,))
        db.execute(
            """INSERT INTO sessions
               (id,name,age,job,questions_json,total,current_idx,created_at,expires_at)
               VALUES (?,?,?,?,?,?,?,?,?)""",
            (_hash(token), name, age, job, json.dumps(questions, ensure_ascii=False),
             len(questions), 0, now, now + config.SESSION_TTL_HOURS * 3600),
        )
    return token

def _session(db, token: str):
    if not token:
        raise SessionError("Sesi tidak tersedia. Silakan mulai tryout baru.", 401)
    session = db.execute("SELECT * FROM sessions WHERE id=?", (_hash(token),)).fetchone()
    if session is None or session["expires_at"] <= time.time():
        raise SessionError("Sesi tidak ditemukan atau telah berakhir. Silakan mulai tryout baru.", 401)
    return session

def _get_answer(db, session, now: float):
    idx = session["current_idx"]
    row = db.execute(
        "SELECT * FROM answers WHERE session_id=? AND idx=?", (session["id"], idx)
    ).fetchone()
    if row is None:
        db.execute(
            "INSERT INTO answers (session_id, idx, started_at, deadline_at) VALUES (?,?,?,?)",
            (session["id"], idx, now, now + 60),
        )
        row = db.execute(
            "SELECT * FROM answers WHERE session_id=? AND idx=?", (session["id"], idx)
        ).fetchone()
    return row

def _expire(db, session, answer, now: float):
    if now >= answer["deadline_at"] and answer["finalized_at"] is None:
        db.execute(
            "UPDATE answers SET finalized_at=? WHERE session_id=? AND idx=? AND finalized_at IS NULL",
            (answer["deadline_at"], session["id"], answer["idx"]),
        )
        answer = db.execute(
            "SELECT * FROM answers WHERE session_id=? AND idx=?",
            (session["id"], answer["idx"]),
        ).fetchone()
    return answer

def _current_view(db, session, now: float) -> dict:
    if session["completed_at"] is not None:
        return {"stage": "results"}
    answer = _expire(db, session, _get_answer(db, session, now), now)
    question = json.loads(session["questions_json"])[session["current_idx"]]
    # Explicit allowlist: no correct answer or explanation ever sent here.
    return {
        "stage": "exam",
        "name": session["name"],
        "index": session["current_idx"],
        "total": session["total"],
        "question": {"id": question["id"], "text": question["text"], "choices": question["choices"]},
        "selected": answer["selected"],
        "locked": answer["finalized_at"] is not None,
        "deadline": answer["deadline_at"],
        "server_now": now,
    }

def get_current(token: str) -> dict:
    with _db(write=True) as db:
        now = time.time()
        session = _session(db, token)
        return _current_view(db, session, now)

def save_answer(token: str, expected_idx: int, selected: str | None) -> dict:
    with _db(write=True) as db:
        now = time.time()
        session = _session(db, token)
        if session["completed_at"] is not None:
            return {"stage": "results"}
        if expected_idx != session["current_idx"]:
            raise SessionError("Soal tersebut tidak aktif dan tidak dapat diubah.", 409)
        answer = _expire(db, session, _get_answer(db, session, now), now)
        if answer["finalized_at"] is not None:
            return _current_view(db, session, now)
        db.execute(
            "UPDATE answers SET selected=? WHERE session_id=? AND idx=? AND finalized_at IS NULL",
            (selected, session["id"], expected_idx),
        )
        return _current_view(db, session, now)

def advance(token: str, expected_idx: int) -> dict:
    with _db(write=True) as db:
        now = time.time()
        session = _session(db, token)
        if session["completed_at"] is not None:
            return {"stage": "results"}
        if expected_idx != session["current_idx"]:
            # Safe idempotence: duplicate / delayed calls never skip a question.
            return _current_view(db, session, now)
        answer = _expire(db, session, _get_answer(db, session, now), now)
        if answer["finalized_at"] is None:
            db.execute(
                "UPDATE answers SET finalized_at=? WHERE session_id=? AND idx=?",
                (min(now, answer["deadline_at"]), session["id"], expected_idx),
            )
        next_idx = expected_idx + 1
        if next_idx >= session["total"]:
            db.execute("UPDATE sessions SET completed_at=? WHERE id=?", (now, session["id"]))
            return {"stage": "results"}
        db.execute(
            "UPDATE sessions SET current_idx=? WHERE id=?", (next_idx, session["id"])
        )
        session = db.execute("SELECT * FROM sessions WHERE id=?", (session["id"],)).fetchone()
        return _current_view(db, session, now)

def get_results(token: str) -> dict:
    with _db() as db:
        session = _session(db, token)
        if session["completed_at"] is None:
            raise SessionError("Hasil baru tersedia setelah tryout selesai.", 403)
        questions = json.loads(session["questions_json"])
        rows = db.execute(
            "SELECT * FROM answers WHERE session_id=? ORDER BY idx ASC", (session["id"],)
        ).fetchall()
        by_idx = {r["idx"]: r for r in rows}
        reviews = []
        correct = wrong = blank = 0
        active_seconds = 0.
        for idx, q in enumerate(questions):
            row = by_idx.get(idx)
            selected = row["selected"] if row else None
            if row is not None:
                active_seconds += max(0., min(60., (row["finalized_at"] or row["deadline_at"]) - row["started_at"]))
            if not selected:
                status = "unanswered"
                blank += 1
            elif selected == q["correct"]:
                status = "correct"
                correct += 1
            else:
                status = "incorrect"
                wrong += 1
            reviews.append({
                "id": q["id"], "text": q["text"], "choices": q["choices"],
                "selected": selected, "correct": q["correct"], "explanation": q["explanation"],
                "source_ref": q.get("source_ref"), "status": status,
            })
        total = len(questions)
        return {
            "stage": "results", "name": session["name"],
            "total": total, "correct": correct, "incorrect": wrong,
            "unanswered": blank, "score": round(correct / total * 100, 2),
            "active_seconds": round(active_seconds, 1), "reviews": reviews,
        }
