"""Server-only runtime configuration; never expose credentials to the browser."""
import os
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent

def _load_env():
    path = PROJECT_ROOT / ".env"
    if not path.is_file():
        return
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip() or line.lstrip().startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

_load_env()

def get(name: str, default: str) -> str:
    return os.getenv(name, default)

def integer(name: str, default: int) -> int:
    try:
        return int(get(name, str(default)))
    except ValueError:
        return default

MAX_UPLOAD_BYTES = max(1, integer("MAX_UPLOAD_MB", 10)) * 1024 * 1024
MIN_SOURCE_WORDS = max(20, integer("MIN_SOURCE_WORDS", 60))
DATABASE_PATH = get("DATABASE_PATH", str(PROJECT_ROOT / "medical_tryout.sqlite3"))
SESSION_TTL_HOURS = max(1, integer("SESSION_TTL_HOURS", 12))
COOKIE_SECURE = get("COOKIE_SECURE", "false").lower() in ("true", "1", "yes")
AI_API_KEY = get("AI_API_KEY", "")
AI_MODEL = get("AI_MODEL", "gpt-4.1-mini")
AI_BASE_URL = get("AI_BASE_URL", "https://api.openai.com/v1")
AI_TIMEOUT_SECONDS = max(10, integer("AI_TIMEOUT_SECONDS", 75))
AI_MAX_RETRIES = min(2, max(0, integer("AI_MAX_RETRIES", 1)))
