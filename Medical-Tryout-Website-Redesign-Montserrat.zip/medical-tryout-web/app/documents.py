"""Extract educational text from untrusted uploads without persisting originals."""
from __future__ import annotations
from dataclasses import dataclass
from io import BytesIO
import re
import zipfile
from pathlib import Path
from pypdf import PdfReader
from docx import Document
from . import config

class DocumentError(ValueError):
    pass

@dataclass(frozen=True)
class ExtractedDocument:
    text: str
    refs: tuple[str, ...]
    filename: str
    word_count: int

def _clean(value: str) -> str:
    value = value.replace("\x00", "")
    value = re.sub(r"[\t ]+", " ", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()

def extract_document(filename: str, data: bytes) -> ExtractedDocument:
    filename = Path(filename).name
    suffix = Path(filename).suffix.lower()
    if len(data) > config.MAX_UPLOAD_BYTES:
        raise DocumentError(f"Berkas terlalu besar. Maksimum {config.MAX_UPLOAD_BYTES // 1048576} MB.")
    if not data:
        raise DocumentError("Berkas kosong. Silakan pilih dokumen lain.")
    if suffix not in (".pdf", ".docx", ".txt"):
        raise DocumentError("Format berkas tidak didukung. Gunakan PDF, DOCX, atau TXT.")
    parts: list[str] = []
    refs: list[str] = []
    try:
        if suffix == ".pdf":
            if not data.startswith(b"%PDF-"):
                raise DocumentError("Berkas PDF tidak valid atau tidak terbaca.")
            reader = PdfReader(BytesIO(data), strict=False)
            if reader.is_encrypted:
                raise DocumentError("PDF dengan kata sandi tidak didukung.")
            if len(reader.pages) > 250:
                raise DocumentError("PDF melebihi batas 250 halaman.")
            for i, page in enumerate(reader.pages, 1):
                txt = _clean(page.extract_text() or "")
                if txt:
                    ref = f"Halaman {i}"
                    refs.append(ref)
                    parts.append(f"[{ref}]\n{txt}")
            if not parts:
                raise DocumentError("PDF tidak memiliki teks yang dapat dibaca. Gunakan PDF berbasis teks, bukan hasil pindai gambar.")
        elif suffix == ".docx":
            if not zipfile.is_zipfile(BytesIO(data)):
                raise DocumentError("Struktur berkas DOCX tidak valid.")
            with zipfile.ZipFile(BytesIO(data)) as zf:
                if "word/document.xml" not in zf.namelist():
                    raise DocumentError("Struktur DOCX tidak memuat dokumen Word.")
                if sum(i.file_size for i in zf.infolist()) > 45 * 1024 * 1024:
                    raise DocumentError("Isi DOCX terlalu besar untuk diproses dengan aman.")
            doc = Document(BytesIO(data))
            current_ref = "Bagian awal"
            for paragraph in doc.paragraphs:
                txt = _clean(paragraph.text)
                if not txt:
                    continue
                if paragraph.style and paragraph.style.name.lower().startswith("heading"):
                    current_ref = f"Bagian: {txt[:100]}"
                if current_ref not in refs:
                    refs.append(current_ref)
                parts.append(f"[{current_ref}]\n{txt}")
            for table in doc.tables:
                for row in table.rows:
                    text = " | ".join(_clean(cell.text) for cell in row.cells)
                    if text.strip(" |"):
                        if current_ref not in refs:
                            refs.append(current_ref)
                        parts.append(f"[{current_ref}]\n{text}")
            if not parts:
                raise DocumentError("DOCX tidak memiliki teks yang dapat dibaca.")
        else:
            if b"\x00" in data:
                raise DocumentError("TXT tampaknya merupakan berkas biner, bukan teks.")
            try:
                txt = data.decode("utf-8-sig")
            except UnicodeDecodeError as exc:
                raise DocumentError("TXT harus menggunakan pengodean UTF-8.") from exc
            txt = _clean(txt)
            if not txt:
                raise DocumentError("TXT kosong atau hanya berisi spasi.")
            refs.append("Dokumen TXT")
            parts.append(f"[Dokumen TXT]\n{txt}")
    except DocumentError:
        raise
    except Exception as exc:
        raise DocumentError("Dokumen tidak dapat diproses. Pastikan berkas tidak rusak.") from exc

    text = "\n\n".join(parts)
    count = len(re.findall(r"\b[\wÀ-ÿ-]+\b", text))
    if count < config.MIN_SOURCE_WORDS:
        raise DocumentError(f"Materi terlalu singkat untuk membuat soal bermutu. Tambahkan materi pembelajaran (minimal sekitar {config.MIN_SOURCE_WORDS} kata).")
    if len(text) > 115_000:
        raise DocumentError("Dokumen terlalu panjang untuk satu tryout. Bagilah materi menjadi beberapa dokumen yang lebih ringkas.")
    return ExtractedDocument(text=text, refs=tuple(refs), filename=filename, word_count=count)
