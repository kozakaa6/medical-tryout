import pytest
from app.ai import validate_questions, GenerationError
from app.documents import ExtractedDocument

DOC=ExtractedDocument(
    filename="materi.txt",
    refs=("Dokumen TXT",),
    text="Tekanan darah meningkat pada hipertensi. Pengukuran tekanan darah berulang dan perubahan gaya hidup merupakan bagian pengelolaan hipertensi.",
    word_count=100,
)

def _q():
    return {
       "text":"Bagaimana pengukuran tekanan darah pada evaluasi hipertensi?",
       "choices":{"A":"Pengukuran tekanan darah berulang","B":"Tanpa pemeriksaan","C":"Pemeriksaan rambut","D":"Evaluasi warna sepatu"},
       "correct":"A","explanation":"Pengukuran tekanan darah berulang digunakan pada evaluasi hipertensi dan penanganannya.",
       "source_ref":"Dokumen TXT"
    }

def test_valid_response():
    result = validate_questions({"questions":[_q()]},DOC)
    assert result[0]["id"]=="q-01" and result[0]["correct"]=="A"

def test_duplicate_choices():
    q=_q();q["choices"]["B"]=q["choices"]["A"]
    with pytest.raises(GenerationError):
        validate_questions({"questions":[q]},DOC)

def test_repeated_questions():
    with pytest.raises(GenerationError):
        validate_questions({"questions":[_q(),_q()]},DOC)

def test_invalid_source_ref():
    q=_q();q["source_ref"]="Halaman 900"
    with pytest.raises(GenerationError):
        validate_questions({"questions":[q]},DOC)

def test_no_related_terms():
    q=_q();q["text"]="Bagaimanakah posisi planet di galaksi bimasakti?";q["explanation"]="Posisi planet ditentukan oleh gravitasi dan kecepatan orbit sistem planet."
    with pytest.raises(GenerationError):
        validate_questions({"questions":[q]},DOC)

def test_missing_correct_field():
    q=_q();del q["correct"]
    with pytest.raises(GenerationError):
        validate_questions({"questions":[q]},DOC)
