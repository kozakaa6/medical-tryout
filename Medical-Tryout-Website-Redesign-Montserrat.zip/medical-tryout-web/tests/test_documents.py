from io import BytesIO
import pytest
import fitz
from docx import Document
from app import documents

TEXT = ("Hipertensi merupakan peningkatan tekanan darah yang perlu dievaluasi secara klinis. "
        "Diagnosis dilakukan menggunakan pengukuran tekanan darah yang tepat serta penilaian faktor risiko. "
        "Terapi mencakup perubahan gaya hidup, aktivitas fisik teratur, dan penilaian kebutuhan obat. "
        "Pemantauan berkala penting untuk mengevaluasi respons pengobatan dan risiko komplikasi. ") * 3

def test_valid_txt():
    doc = documents.extract_document("materi.txt", TEXT.encode())
    assert doc.word_count > 60 and doc.refs == ("Dokumen TXT",)

def test_valid_pdf_with_page_reference():
    pdf = fitz.open()
    page = pdf.new_page()
    page.insert_text((30, 30), TEXT, fontsize=8)
    doc = documents.extract_document("materi.pdf", pdf.tobytes())
    assert "Halaman 1" in doc.refs

def test_valid_docx():
    docx = Document()
    docx.add_heading("Hipertensi", 1)
    docx.add_paragraph(TEXT)
    buf=BytesIO();docx.save(buf)
    doc = documents.extract_document("materi.docx",buf.getvalue())
    assert any(r.startswith("Bagian:") for r in doc.refs)

def test_pdf_image_only_is_rejected():
    pdf=fitz.open();pdf.new_page()
    with pytest.raises(documents.DocumentError, match="berbasis teks"):
        documents.extract_document("pindai.pdf",pdf.tobytes())

@pytest.mark.parametrize("name,bytestr", [
    ("bad.pdf",b"not-a-pdf"), ("fake.docx",b"not-a-docx"),
    ("binary.txt",b"\x00hello"), ("image.png",b"not-png"),
    ("blank.txt",b"  "), ("empty.txt",b""),
])
def test_invalid_upload(name, bytestr):
    with pytest.raises(documents.DocumentError):
        documents.extract_document(name,bytestr)

def test_too_short_material():
    with pytest.raises(documents.DocumentError, match="terlalu singkat"):
        documents.extract_document("short.txt",b"halo dokter")
