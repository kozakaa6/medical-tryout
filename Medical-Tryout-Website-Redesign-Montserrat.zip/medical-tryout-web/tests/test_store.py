import sqlite3
import time
import pytest
from app import store, config

QUESTIONS=[
    {"id":"q-01","text":"Bagaimana pemeriksaan tekanan darah?",
     "choices":{"A":"Jawab A","B":"Jawab B","C":"Jawab C","D":"Jawab D"},
     "correct":"A","explanation":"Keterangan pertama","source_ref":"Halaman 1"},
    {"id":"q-02","text":"Bagaimana pemantauan tekanan darah?",
     "choices":{"A":"Jawab A","B":"Jawab B","C":"Jawab C","D":"Jawab D"},
     "correct":"C","explanation":"Keterangan kedua","source_ref":"Halaman 1"},
]

@pytest.fixture(autouse=True)
def store_test_database(tmp_path,monkeypatch):
    monkeypatch.setattr(config,"DATABASE_PATH",str(tmp_path/"test.db"))
    store.initialize()

def test_session_no_answer_leak_and_idempotent():
    token=store.create_session("Budi",22,"Koas",QUESTIONS)
    data=store.get_current(token)
    assert data["stage"]=="exam" and data["index"]==0
    assert "correct" not in repr(data) and "explanation" not in repr(data)
    assert data["deadline"]-data["server_now"]<=60
    with pytest.raises(store.SessionError):
        store.get_results(token)
    store.save_answer(token,0,"A")
    assert store.get_current(token)["selected"]=="A"
    progressed=store.advance(token,0)
    assert progressed["index"]==1
    assert store.advance(token,0)["index"]==1
    with pytest.raises(store.SessionError):
        store.save_answer(token,0,"C")
    assert store.advance(token,1)["stage"]=="results"
    results=store.get_results(token)
    assert (results["correct"],results["incorrect"],results["unanswered"])==(1,0,1)
    assert results["score"]==50
    assert sum([results["correct"],results["incorrect"],results["unanswered"]])==results["total"]
    assert results["active_seconds"]<=120

def test_expiry_locks_answer_preserves_last_selection_and_waits_for_advance():
    token=store.create_session("Sari",30,"Dokter",QUESTIONS)
    store.get_current(token)
    store.save_answer(token,0,"B")
    with store._db(write=True) as db:
        db.execute("UPDATE answers SET started_at=?,deadline_at=? WHERE idx=0",
                   (time.time()-80,time.time()-20))
    view=store.get_current(token)
    assert view["locked"] is True and view["selected"]=="B" and view["index"]==0
    assert store.save_answer(token,0,"A")["selected"]=="B"
    assert store.get_current(token)["index"]==0
    assert store.advance(token,0)["index"]==1
    assert store.advance(token,1)["stage"]=="results"
    result=store.get_results(token)
    assert result["incorrect"]==1 and result["unanswered"]==1
    assert 59 <= result["active_seconds"] <= 61

def test_unknown_session_fails():
    with pytest.raises(store.SessionError):
        store.get_current("unknown-session")
