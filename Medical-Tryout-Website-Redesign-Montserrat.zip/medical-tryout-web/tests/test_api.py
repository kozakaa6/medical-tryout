import json
import pytest
from fastapi.testclient import TestClient
from app import config,ai,store
from app.main import app

TXT = ("Materi hipertensi membahas peningkatan tekanan darah. Evaluasi dilakukan dengan "
       "pengukuran tekanan darah berulang. Penanganan meliputi perubahan pola makan, "
       "olahraga, pemantauan komplikasi, dan evaluasi respons terapi. ")*6

def sample():
    return [{"id":"q-01","text":"Apa cara evaluasi tekanan darah pada hipertensi?",
       "choices":{"A":"Pengukuran berulang","B":"Tidak diperiksa","C":"Lihat sepatu","D":"Lihat rambut"},
       "correct":"A","explanation":"Materi menyebut pengukuran tekanan darah berulang untuk evaluasi.",
       "source_ref":"Dokumen TXT"}]

@pytest.fixture
def client(tmp_path,monkeypatch):
    monkeypatch.setattr(config,"DATABASE_PATH",str(tmp_path/"api.db"))
    with TestClient(app) as c:
        yield c

def test_no_ai_credential_returns_true_error(client,monkeypatch):
    monkeypatch.setattr(config,"AI_API_KEY","")
    response=client.post("/api/generate", data={"name":"Budi","age":"25"},
       files={"file":("materi.txt",TXT.encode(),"text/plain")})
    assert response.status_code==200
    events=[json.loads(x) for x in response.text.strip().splitlines()]
    assert events[-1]["type"]=="error"
    assert "AI_API_KEY" in events[-1]["message"]
    assert client.get("/api/session").status_code==401

def test_e2e_upload_exam_result(client,monkeypatch):
    async def fake_ai(doc):
        assert doc.word_count>60
        return sample()
    monkeypatch.setattr(ai,"generate_questions",fake_ai)  # Test-only double; no production fallback.
    response=client.post("/api/generate",data={"name":"Citra","age":"25","job":"Dokter"},
        files={"file":("materi.txt",TXT.encode(),"text/plain")})
    assert response.status_code==200
    events=[json.loads(x) for x in response.text.strip().splitlines()]
    assert [e["type"] for e in events]==["phase","phase","phase","ready"]
    active=client.get("/api/session").json()
    assert active["question"]["id"]=="q-01"
    assert "correct" not in active["question"] and "explanation" not in active["question"]
    assert client.get("/api/results").status_code==403
    selected=client.put("/api/answer",json={"index":0,"selected":"A"})
    assert selected.status_code==200 and selected.json()["selected"]=="A"
    assert client.post("/api/advance",json={"index":0}).json()["stage"]=="results"
    results=client.get("/api/results").json()
    assert results["correct"]==1 and results["score"]==100
    assert results["reviews"][0]["correct"]=="A"
    client.post("/api/reset")
    assert client.get("/api/session").status_code==401

def test_validation_rejects_invalid_upload(client):
    res=client.post("/api/generate",data={"name":"A","age":"-2"},
       files={"file":("pic.jpg",b"image","image/jpeg")})
    assert res.status_code==422
    assert "Nama" in res.json()["detail"]

def test_mutation_requires_cookie(client):
    assert client.put("/api/answer",json={"index":0,"selected":"A"}).status_code==401
    assert client.post("/api/advance",json={"index":0}).status_code==401
